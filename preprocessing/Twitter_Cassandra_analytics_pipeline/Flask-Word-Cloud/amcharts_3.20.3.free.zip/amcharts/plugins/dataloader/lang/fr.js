AmCharts.translations.dataLoader.fr = {
  'Error loading the file': 'Erreur lors du chargement du fichier',
  'Error parsing JSON file': 'Erreur lors de l\'analyse du fichier JSON',
  'Unsupported data format': 'Le format des données n\'est pas supporté',
  'Loading data...': 'Chargement des données...'
}